# Grav Milkdown Editor Integration

The **Milkdown Editor** Plugin is an extension for [Grav CMS](https://github.com/getgrav/grav). It adds a WYSIWYG markdown editor based on [Milkdown](https://milkdown.dev/).

## Installation

To install the plugin manually, download the zip-version of this repository and unzip it under `/your/site/grav/user/plugins`. Then rename the folder to `milkdown-editor`. You can find these files on [GitHub](https://github.com/Ocarthon/grav-plugin-milkdown-editor/releases).

You should now have all the plugin files under

    /your/site/grav/user/plugins/milkdown-editor
