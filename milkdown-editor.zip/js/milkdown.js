import { Crepe } from "@milkdown/crepe";

import style from "@milkdown/crepe/theme/common/style.css";
import theme from "@milkdown/crepe/theme/nord.css";

export function crepe() {
    style;
    theme;

    return Crepe;
}
